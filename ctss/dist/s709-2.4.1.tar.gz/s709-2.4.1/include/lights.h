
void lights();
void pview(int);
void help();
void trace();
void long_trace();
