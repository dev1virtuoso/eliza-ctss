uint8 getfmtchar (uint8 *, uint32);
void active_7909(int ch);
void start_7909(int ch);
void load_7909(int ch);
void diag_7909(int ch, uint16);
void reset_7909(int ch);
void check_7909(int ch);
int boot_7909(char *ch);
void load_drum(int ch);
