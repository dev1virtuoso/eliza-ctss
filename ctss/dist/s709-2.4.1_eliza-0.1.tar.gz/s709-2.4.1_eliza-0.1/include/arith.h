void add();
void rnd(int);
void mpy();
void intdiv();
void fadd(int nrm);
void frnd();
void fmpy(int nrm);
void fdiv();
void dfadd(int nrm);
void dfrnd();
void dfmpy(int nrm);
void dfdiv();

