
void negop();

